<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Restaurant;

class RestaurantController extends Controller
{
    public function index()
    {
        $restaurant = Restaurant::all();
        return response()->json($restaurant);
    }

    public function store(Request $request)
    {
        $request->validate(
            [
                'name' => 'required|string',
                'address' => 'required|string',
                'phone_number' => 'required|string',
                'rating' => 'required|numeric',
                'logo_url' => 'required|string'
            ]
        );

        $restaurant = Restaurant::create([
            'name' => $request->name,
            'address' => $request->address,
            'phone_number' => $request->phone_number,
            'rating' => $request->rating,
            'logo_url' => $request->logo_url
        ]);

        return response()->json([
            'message' => 'Restaurant Created Successfully',
            'data' => $restaurant
        ]);
    }

    public function show(Request $request)
    {
        $request->validate(
            [
                'name' => 'required|string',
                'address' => 'required|string',
            ]
        );

        $restaurant = Restaurant::where('name', 'like', '%' . $request->name . '%')
                        ->where('address', 'like', '%' . $request->address . '%')
                        ->get();
        
        if($restaurant->count() > 0) {
            return response()->json([
                'message' => 'Pemesanan found',
                'data' => $restaurant
            ], 200);
        } else {
            return response()->json([
                'message' => 'Pemesanan not found'
            ], status: 403);
        }
        
    }

    public function destroy(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
        ]);

        $restaurant = pemesanan::where('name', 'like', '%' . $request->name . '%')->first();

        if($restaurant->count() > 0) {
            $restaurant->delete();
            return response()->json([
                'message' => 'Pemesanan deleted successfully'
            ], 200);
        } else {
            return response()->json([
                'message' => 'Pemesanan not found'
            ], 404);
        }
    }
}
